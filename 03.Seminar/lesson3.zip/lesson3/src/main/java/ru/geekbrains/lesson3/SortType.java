package ru.geekbrains.lesson3;

public enum SortType {
    Ascending,
    Descending
}
