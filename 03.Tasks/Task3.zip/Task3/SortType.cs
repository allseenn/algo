﻿namespace Task3
{
    public enum SortType
    {
        Ascending,
        Descending
    }
}
